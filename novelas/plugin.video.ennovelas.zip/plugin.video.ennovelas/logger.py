import xbmc


def debug(mensaje):
    xbmc.log("ENNOVELAS ADDON: "+str(mensaje), xbmc.LOGERROR);
