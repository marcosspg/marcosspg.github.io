import xbmc


def debug(mensaje):
    xbmc.log("ENNOVELAS ADDON: "+mensaje);